package agile.java.backend.code.challenge.service;


import agile.java.backend.code.challenge.model.User;
import agile.java.backend.code.challenge.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    private User user;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        user = new User();
        user.setUserName("johndoe");
        user.setName("John Doe");
        user.setEmail("john.doe@example.com");
        user.setGender("male");
        user.setPicture("https://example.com/pic.jpg");
    }

    @Test
    void testCreateUser() {
        when(userRepository.save(user)).thenReturn(user);

        User createdUser = userService.createUser(user);

        assertNotNull(createdUser);
        assertEquals("johndoe", createdUser.getUserName());
        verify(userRepository, times(1)).save(user);
    }

    @Test
    void testGetUserByUsername() {
        when(userRepository.findById("johndoe")).thenReturn(Optional.of(user));

        Optional<User> foundUser = userService.getUserByUsername("johndoe");

        assertTrue(foundUser.isPresent());
        assertEquals("johndoe", foundUser.get().getUserName());
    }

    @Test
    void testUpdateUser() {
        when(userRepository.existsById("johndoe")).thenReturn(true);
        when(userRepository.save(user)).thenReturn(user);

        User updatedUser = userService.updateUser("johndoe", user);

        assertNotNull(updatedUser);
        assertEquals("johndoe", updatedUser.getUserName());
    }

    @Test
    void testDeleteUser() {
        when(userRepository.existsById("johndoe")).thenReturn(true);

        boolean isDeleted = userService.deleteUser("johndoe");

        assertTrue(isDeleted);
        verify(userRepository, times(1)).deleteById("johndoe");
    }
}

