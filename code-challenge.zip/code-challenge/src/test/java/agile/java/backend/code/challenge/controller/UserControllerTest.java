package agile.java.backend.code.challenge.controller;

import agile.java.backend.code.challenge.model.User;
import agile.java.backend.code.challenge.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class UserControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    private MockMvc mockMvc;
    private User user;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();

        user = new User();
        user.setUserName("ashish");
        user.setName("Ashish");
        user.setEmail("ashish@example.com");
        user.setGender("male");
        user.setPicture("https://example.com/pic.jpg");
    }

    @Test
    void testGetAllUsersWithPagination() throws Exception {
        Page<User> pagedResponse = new PageImpl<>(List.of(user), PageRequest.of(0, 10), 1);
        when(userService.getAllUsers(PageRequest.of(0, 10))).thenReturn(pagedResponse);

        mockMvc.perform(get("/api/users/?page=0&size=10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content[0].userName").value("ashish"))
                .andExpect(jsonPath("$.totalElements").value(1))
                .andExpect(jsonPath("$.totalPages").value(1));
    }

    @Test
    void testCreateUser() throws Exception {
        when(userService.createUser(user)).thenReturn(user);

        mockMvc.perform(post("/api/users/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\": \"ashish\", \"name\": \"Ashish\", \"email\": \"ashish@example.com\", \"gender\": \"male\", \"picture\": \"https://example.com/pic.jpg\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.userName").value("ashish"));
    }

    @Test
    void testGetUserByUsername() throws Exception {
        when(userService.getUserByUsername("ashish")).thenReturn(Optional.of(user));

        mockMvc.perform(get("/api/users/ashish"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userName").value("ashish"));
    }

    @Test
    void testUpdateUser() throws Exception {
        when(userService.updateUser("ashish", user)).thenReturn(user);

        mockMvc.perform(put("/api/users/ashish")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"userName\": \"ashish\", \"name\": \"Ashish Updated\", \"email\": \"ashish.updated@example.com\", \"gender\": \"male\", \"picture\": \"https://example.com/updatedpic.jpg\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userName").value("ashish"));
    }

    @Test
    void testDeleteUser() throws Exception {
        when(userService.deleteUser("ashish")).thenReturn(true);

        mockMvc.perform(delete("/api/users/ashish"))
                .andExpect(status().isOk());
    }
}
