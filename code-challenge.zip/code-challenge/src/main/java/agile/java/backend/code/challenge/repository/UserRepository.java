package agile.java.backend.code.challenge.repository;

import agile.java.backend.code.challenge.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, String> {
}

